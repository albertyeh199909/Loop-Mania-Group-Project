package unsw.loopmania.buildings;

public class VampireCastle extends Spawner {
    public VampireCastle() {
        super("Vampire Castle", 3, 5);
    }
}