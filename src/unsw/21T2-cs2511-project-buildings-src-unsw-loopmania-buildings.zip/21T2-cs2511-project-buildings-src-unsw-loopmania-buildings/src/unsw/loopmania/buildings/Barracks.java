package unsw.loopmania.buildings;

public class Barracks extends Building {
    public Barracks() {
        super("Barracks", 1);
    }
}