package unsw.loopmania.buildings;

public class HerosCastle extends Building {
    public HerosCastle() {
        super("Hero's Castle", 4);
    }
}