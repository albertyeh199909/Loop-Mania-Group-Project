package unsw.loopmania.buildings;

public class ZombiePit extends Spawner {
    public ZombiePit() {
        super("Zombie Pit", 3, 1);
    }
}